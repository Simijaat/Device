# Device Manager APK Installation

This ZIP file contains the `app-debug.apk` file for the Device Manager app.

## How to Install

1. Extract this ZIP file. You will get a file named `app-debug.apk`.
2. Do not tap the `.zip` file directly from a messenger or browser, as Android will likely fail to launch the installer.
3. Open your Android phone's built-in **Files** or **My Files** app.
4. Navigate to where you extracted the `app-debug.apk` file.
5. Tap on `app-debug.apk` to begin installation.
6. If prompted, allow your File Manager app to **"Install unknown apps"**.
7. Once installed, tap "Open" or find "Device Manager" in your app drawer.
